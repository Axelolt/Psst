/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.SpinnerNumberModel;

/**
 *
 * @author XL
 */
public class ProductoView extends JFrame {
    
    private JSpinner spinnerIdProducto;
    private JTextField txtNombreProducto;
    private JSpinner spinnerPrecioProducto;
    private JSpinner spinnerExistenciaProducto;
    private JSpinner spinnerFechaProducto;
    private JRadioButton radioDescontinuado;
    private JComboBox<String> comboLineaProducto;
    private JButton btnEnviar;

    //CONSTRUCTOR VACIO
    public ProductoView() {
        
        setTitle("DATOS DEL PRODUCTO");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));
        
        //PANEL SUPERIOR
        JPanel panelSuperior = new JPanel();
        panelSuperior.setBackground(new Color(204, 229, 255));
        panelSuperior.add(new JLabel("Formulario de Producto"));
        add(panelSuperior, BorderLayout.NORTH);
        
        //PANEL CENTRAL
        JPanel panelCentro = new JPanel(new GridLayout(7,2,10,10));
        panelCentro.setBorder(BorderFactory.createTitledBorder("Datos"));
        panelCentro.setBackground(new Color(204, 229, 255));
        
        //CREAR LAS INSTANCIAS - CREAR LOS OBJETOS
        
        /*spinnerIdProducto = new JSpinner(new SpinnerNumberModel
        (1, <-- Valor inicial
        1,  <-- Valor minimo
        10, <-- Valor maximo
        1));<-- Incremento
        */
        
        spinnerIdProducto = new JSpinner(new SpinnerNumberModel(1, 1, 10, 1));
        txtNombreProducto = new JTextField(40); //El tamaño del campo es de 40
        radioDescontinuado = new JRadioButton("Desontinuado");
        spinnerPrecioProducto = new JSpinner (new SpinnerNumberModel(10.00, 10.00, 1000, 0.50));
        spinnerExistenciaProducto = new JSpinner(new SpinnerNumberModel(5, 5, 50, 1));
        spinnerFechaProducto = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor editor = new JSpinner.DateEditor(spinnerFechaProducto, "dd/MM/yyyy");
        spinnerFechaProducto.setEditor(editor);
        comboLineaProducto = new JComboBox<>(new String[]{
            "Cristaleria", "Cosmeticos", "Perfumeria"
        });
        btnEnviar = new JButton("Enviar");
        
        //AGREGAR LOS COMPONENTES AL PANEL
        panelCentro.add(new JLabel("ID del Producto "));
        panelCentro.add(spinnerIdProducto);
        
        panelCentro.add(new JLabel("Nombre del Producto "));
        panelCentro.add(txtNombreProducto);
        
        panelCentro.add(new JLabel("Precio $"));
        panelCentro.add(spinnerPrecioProducto);
        
        panelCentro.add(new JLabel("Existencia "));
        panelCentro.add(spinnerExistenciaProducto);
        
        panelCentro.add(new JLabel("Fecha de Vencimiento "));
        panelCentro.add(spinnerFechaProducto);
        
        panelCentro.add(new JLabel("Linea de Producto "));
        panelCentro.add(comboLineaProducto);
        
        panelCentro.add(new JLabel("Estado "));
        panelCentro.add(radioDescontinuado);
        
        add(panelCentro, BorderLayout.CENTER); //AGREGAR EL "panelCentro" AL JFRAME
        
        //PANEL INFERIOR
        JPanel panelInferior = new JPanel();
        panelInferior.setBackground(new Color(204, 229, 255));
        panelInferior.add(this.btnEnviar);
        
        add(panelInferior, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(null);
        setResizable(false);
    }   
        //AGREGAR METODOS GETTER

    public JSpinner getSpinnerIdProducto() {
        return spinnerIdProducto;
    }

    public JTextField getTxtNombreProducto() {
        return txtNombreProducto;
    }

    public JSpinner getSpinnerPrecioProducto() {
        return spinnerPrecioProducto;
    }

    public JSpinner getSpinnerExistenciaProducto() {
        return spinnerExistenciaProducto;
    }

    public JSpinner getSpinnerFechaProducto() {
        return spinnerFechaProducto;
    }

    public JRadioButton getRadioDescontinuado() {
        if (this.radioDescontinuado.isSelected()){
             System.out.println("Descontinuado");
             return radioDescontinuado;
        }else{
            System.out.println("No descontinuado");
            return radioDescontinuado;
        }
        
    }

    public JComboBox<String> getComboLineaProducto() {
        return comboLineaProducto;
    }

    public JButton getBtnEnviar() {
        return btnEnviar;
    }
        
    //METODO PARA NO IMPRIMIR FALSO O VERDADERO
    
    
        
    
}
