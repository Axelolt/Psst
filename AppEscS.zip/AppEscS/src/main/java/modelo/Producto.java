/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.Date;

/**
 *
 * @author XL
 */
public class Producto {

    private int idProducto;
    private String nombreProducto;
    private double precioProducto;
    private int existenciaProducto;
    private Date fechaVencimineto;
    private String descontinuado;
    private String lineaProducto;

    public Producto() {
    }

    //CONSTRUCTOR 1
    public Producto(int idProducto, String nombreProducto) {
        this.idProducto = idProducto;
        this.nombreProducto = nombreProducto;
    }

    //CONSTRUCTOR 2
    public Producto(int idProducto, String nombreProducto, double precioProducto, 
    int existenciaProducto, Date fechaVencimineto) {
        this.idProducto = idProducto;
        this.nombreProducto = nombreProducto;
        this.precioProducto = precioProducto;
        this.existenciaProducto = existenciaProducto;
    }

    //CONSTRUCTOR 3
    public Producto(int idProducto, String nombreProducto, double precioProducto, 
    int existenciaProducto, Date fechaVencimineto, String descontinuado, String lineaProducto) {
        this.idProducto = idProducto;
        this.nombreProducto = nombreProducto;
        this.precioProducto = precioProducto;
        this.existenciaProducto = existenciaProducto;
        this.fechaVencimineto = fechaVencimineto;
        this.descontinuado = descontinuado;
        this.lineaProducto = lineaProducto;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public double getPrecioProducto() {
        return precioProducto;
    }

    public int getExistenciaProducto() {
        return existenciaProducto;
    }

    public Date getFechaVencimineto() {
        return fechaVencimineto;
    }

    public String getDescontinuado() {
        return descontinuado;
    }
    
    

    public String getLineaProducto() {
        return lineaProducto;
    }

    @Override
    public String toString() {
        return "Producto"
                + "\nID: " + idProducto
                + "\nNombre del Producto: " + nombreProducto
                + "\nPrecio: $" + precioProducto
                + "\nExistencia del producto: " + existenciaProducto
                + "\nFecha de vencimineto: " + fechaVencimineto
                + "\nEstado: " + descontinuado
                + "\nLinea de producto: " + lineaProducto + "\n";
    }

    

}
