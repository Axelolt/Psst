/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package test;

import controlador.ProductoController;
import javax.swing.SwingUtilities;
import vista.ProductoView;

/**
 *
 * @author XL
 */
public class AppEsc_ProdctoSwing {

    public static void main(String[] args) {
        
        SwingUtilities.invokeLater(() -> {
            ProductoView vista = new ProductoView();
            ProductoController productoControl = new ProductoController(vista);
            vista.setVisible(true);
        });
        
    }
}
