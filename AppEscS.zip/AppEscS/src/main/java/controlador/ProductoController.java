/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import modelo.Producto;
import vista.ProductoView;

/**
 *
 * @author XL
 */
public class ProductoController {

    private ProductoView vista;

    public ProductoController() {
    }

    public ProductoController(ProductoView vista) {

        this.vista = vista;

        //EL BOTON ENVIAR DEBE ESCUCHAR PARA EJECUTAR EL EVENTO
        this.vista.getBtnEnviar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                capturarDatos();
            }
        });
    }

    private void capturarDatos() {
        int idProd = (int) this.vista.getSpinnerIdProducto().getValue();
        String nombreProd = this.vista.getTxtNombreProducto().getText();
        double precioProd = (double) this.vista.getSpinnerPrecioProducto().getValue();
        int exisProd = (int) this.vista.getSpinnerExistenciaProducto().getValue();
        Date fechaProd = (Date) this.vista.getSpinnerFechaProducto().getValue();
        String descProd = this.vista.getRadioDescontinuado().getText();
        String lineaProd = this.vista.getComboLineaProducto().getSelectedItem().toString();

        Producto prod = new Producto(idProd, nombreProd, precioProd, exisProd, fechaProd, descProd, lineaProd);
        System.out.println("Registro guardado exitosamente.");
        System.out.println(prod);
    }

}
