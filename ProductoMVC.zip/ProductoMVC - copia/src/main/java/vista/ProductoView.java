/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.text.DecimalFormat;
import java.util.Date;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.text.NumberFormatter;

/**
 *
 * @author XL
 */
public class ProductoView extends JFrame {

    private JSpinner spinnerIdProducto;
    private JTextField txtNombreProdcto;
    private JTextArea txtAreaDescripcionProducto;
    private JFormattedTextField ftxtPrecioProducto;
    private JSpinner spinnerExistenciaProducto;
    private JSpinner spinnerFechaVencimiento;
    private JCheckBox chkDescontinuar;
    private JSlider sliderDescuentoProducto;
    private JComboBox<String> comboLineaProducto;
    private JButton btnEnviar;

    //CONSTRUCTOR VACIO
    public ProductoView() {
        setTitle("Título del Formulario");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        //PANEL SUPERIOR
        JPanel panelSuperior = new JPanel();
        panelSuperior.setBackground(new Color(204, 229, 255));
        panelSuperior.add(new JLabel("DATOS DEL PRODUCTO"));
        add(panelSuperior, BorderLayout.NORTH); //PANEL SUPERIOR

        //PANEL CENTRAL
        JPanel panelCentro = new JPanel(new GridBagLayout());
        panelCentro.setBorder(BorderFactory.createTitledBorder("Datos del Producto"));
        panelCentro.setBackground(new Color(224, 229, 255));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        //CREAR INSTANCIAS
        this.spinnerIdProducto = new JSpinner(new SpinnerNumberModel(1, 1, 10, 1));
        this.txtNombreProdcto = new JTextField(20);
        txtAreaDescripcionProducto = new JTextArea(4, 20);
        txtAreaDescripcionProducto.setLineWrap(true);
        txtAreaDescripcionProducto.setWrapStyleWord(true);

        JScrollPane scrollDescripcion = new JScrollPane(txtAreaDescripcionProducto);
        DecimalFormat formato = new DecimalFormat("$0.00");
        NumberFormatter formatter = new NumberFormatter(formato);

        formatter.setValueClass(Double.class);
        formatter.setMinimum(0.0);
        formatter.setMaximum(1000.00);
        formatter.setAllowsInvalid(false);
        ftxtPrecioProducto = new JFormattedTextField(formatter);
        ftxtPrecioProducto.setColumns(10);
        ftxtPrecioProducto.setValue(0.00);

        spinnerExistenciaProducto = new JSpinner(new SpinnerNumberModel(5, 5, 50, 1));
        spinnerFechaVencimiento = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor editor = new JSpinner.DateEditor(spinnerFechaVencimiento, "dd/MM/yyyy");
        spinnerFechaVencimiento.setEditor(editor);

        comboLineaProducto = new JComboBox<>(new String[]{
            "Perfumeria", "Cosméticos", "Cristalería"
        });

        this.chkDescontinuar = new JCheckBox("Descontinuado");
        this.sliderDescuentoProducto = new JSlider(0, 50, 0); //MINIMO-MAXIMO-INICIAL
        this.sliderDescuentoProducto.setMajorTickSpacing(10); //ANCHO MAXIMO
        this.sliderDescuentoProducto.setMinorTickSpacing(5); //ANCHO MINIMO
        this.sliderDescuentoProducto.setPaintLabels(true); //PINTAR LAS MARCAS
        this.sliderDescuentoProducto.setPaintTicks(true); //MOSTRAR LA ESCALA
        
        this.btnEnviar = new JButton("Enviar");

        //AGREGAR COMPONENTES
        gbc.gridx = 0;
        gbc.gridy = 0;
        panelCentro.add(new JLabel("Id:"), gbc);

        gbc.gridx = 1;
        panelCentro.add(spinnerIdProducto, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        panelCentro.add(new JLabel("Nombre:"), gbc);

        gbc.gridx = 1;
        panelCentro.add(txtNombreProdcto, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        panelCentro.add(new JLabel("Descripción:"), gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.BOTH;
        panelCentro.add(scrollDescripcion, gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy++;
        panelCentro.add(new JLabel("Precio:"), gbc);

        gbc.gridx = 1;
        panelCentro.add(ftxtPrecioProducto, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        panelCentro.add(new JLabel("Existencia:"), gbc);

        gbc.gridx = 1;
        panelCentro.add(spinnerExistenciaProducto, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        panelCentro.add(new JLabel("Fecha Vencimiento:"), gbc);

        gbc.gridx = 1;
        panelCentro.add(spinnerFechaVencimiento, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        panelCentro.add(new JLabel("Línea Producto:"), gbc);

        gbc.gridx = 1;
        panelCentro.add(comboLineaProducto, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        panelCentro.add(new JLabel("Descontinuado:"), gbc);

        gbc.gridx = 1;
        panelCentro.add(chkDescontinuar, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        panelCentro.add(new JLabel("Descuento:"), gbc);

        gbc.gridx = 1;
        panelCentro.add(sliderDescuentoProducto, gbc);

        add(panelCentro, BorderLayout.CENTER);

        // ===== PANEL INFERIOR =====
        JPanel panelInferior = new JPanel();
        panelInferior.setBackground(new Color(153, 204, 255));
        panelInferior.add(btnEnviar);

        add(panelInferior, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(null);
        setResizable(false);
    }

    // ===== GETTERS =====
    public JSpinner getSpinnerIdProducto() {
        return spinnerIdProducto;
    }

    public JTextField getTxtNombreProducto() {
        return txtNombreProdcto;
    }

    public JSpinner getSpinnerExistenciaProducto() {
        return spinnerExistenciaProducto;
    }

    public Date getSpinnerFechaVencimiento() {
        return (Date) spinnerFechaVencimiento.getValue();
    }

    public JComboBox<String> getComboLineaProducto() {
        return comboLineaProducto;
    }

    public JTextArea getTxtAreaDescripcionProducto() {
        return txtAreaDescripcionProducto;
    }

    public JFormattedTextField getFtxtPrecioProducto() {
        return ftxtPrecioProducto;
    }

    //public JCheckBox getChkDescontinuar() {
    //     return chkDescontinuar;
    //}
    public boolean isDescontinuado() {
        return chkDescontinuar.isSelected();
    }

    public JSlider getSliderDescuentoProducto() {
        return sliderDescuentoProducto;
    }

    public JButton getBtnEnviar() {
        return btnEnviar;
    }
}

        
        
    
