/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.text.DecimalFormat;
import java.util.Date;

/**
 *
 * @author XL
 */
public class Producto {

    private int idProducto;
    private String nombreProducto;
    private double precioProducto;
    private int existencia;
    private Date fechaVencimiento;
    // private String descontinuado;
    private boolean descontinuado; // agregado
    private int descuento;// agregado asociado al slider
    private String descripcionProducto; // agregado asociado a private JTextArea txtDescripcion;
    private String lineaProducto;

    public Producto() {
    }

    public Producto(int idProducto, String nombreProducto, double precioProducto, int existencia, Date fechaVencimiento, boolean descontinuado, int descuento, String descripcionProducto, String lineaProducto) {
        this.idProducto = idProducto;
        this.nombreProducto = nombreProducto;
        this.precioProducto = precioProducto;
        this.existencia = existencia;
        this.fechaVencimiento = fechaVencimiento;
        this.descontinuado = descontinuado;
        this.descuento = descuento;
        this.descripcionProducto = descripcionProducto;
        this.lineaProducto = lineaProducto;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public double getPrecioProducto() {
        return precioProducto;
    }

    public int getExistencia() {
        return existencia;
    }

    public Date getFechaVencimiento() {
        return fechaVencimiento;
    }

    public boolean isDescontinuado() {
        return descontinuado;
    }

    public int getDescuento() {
        return descuento;
    }

    public String getDescripcionProducto() {
        return descripcionProducto;
    }

    public String getLineaProducto() {
        return lineaProducto;
    }

    @Override
    public String toString() {
        DecimalFormat df = new DecimalFormat("#0.00");
        return "Producto" + 
                "\nID del Producto: " + idProducto + 
                "\nNombre del Producto: " + nombreProducto + 
                "\nPrecio del Producto: $" + precioProducto + 
                "\nExistencias: " + existencia + 
                "\nFecha de Vencimiento: " + fechaVencimiento + 
                "\nDescontinuado: " + descontinuado + 
                "\nDescuento: " + descuento + "%" + 
                "\nDescripcionProducto=" + descripcionProducto + 
                "\nLinea de Producto=" + lineaProducto + 
                "\nPrecio con Descuento: $" + df.format(calcularPrecioConDescuento());
    }

    public double calcularPrecioConDescuento() {

        double montoDescuento = precioProducto * descuento / 100;

        return precioProducto - montoDescuento;
    }

}
