/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.productomvc;

import controlador.ProductoController;
import javax.swing.SwingUtilities;
import vista.ProductoView;

/**
 *
 * @author XL
 */
public class ProductoTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         // Para asegurar que tíldes las palabras
        System.setProperty("file.encoding", "UTF-8");
        
        try {
            System.setOut(new java.io.PrintStream(System.out, true, "UTF-8"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        // fin de código para tildar las palabras
        
         SwingUtilities.invokeLater(()->{
           ProductoView vista = new ProductoView();
           ProductoController cc= new ProductoController(vista);
           vista.setVisible(true);
       });
    }
    
}