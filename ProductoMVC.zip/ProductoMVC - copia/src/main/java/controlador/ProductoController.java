/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import modelo.Producto;
import vista.ProductoView;

/**
 *
 * @author XL
 */
public class ProductoController {

    private ProductoView vista;

    public ProductoController() {
    }

    public ProductoController(ProductoView vista) {
        this.vista = vista;

        // CÓDIGO AGREGADO AL CONSTRUCTOR DEL CONTROLADOR
        // Escuchar el botón
        this.vista.getBtnEnviar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e
            ) {
                enviarProducto();
            }// FIN DE actionPerformed
        } // FIN DE new ActionListener()
        ); // FIN DE addActionListener
    }// FIN DE CONSTRUCTOR ProductoController

    // MÉTODO PARA AGREGAR DATOS DE PACIENTE
    private void enviarProducto() {

        // Capturar datos desde la vista
        /*
        El método: getValue()
        de JSpinner siempre devuelve un Object.
        Entonces:
        vista.getSpinnerIdProducto().getValue()
        retorna un Object, no un int ni un double.
        Por tanto deben haber un casts
         */
        //casts (conversiones de tipo)
        int idProd = (int) vista.getSpinnerIdProducto().getValue();

        String nombreProd = vista.getTxtNombreProducto().getText();

        double precioProd = (Double) vista.getFtxtPrecioProducto().getValue();

        int existenciaProd = (int) vista.getSpinnerExistenciaProducto().getValue();

        java.util.Date fechaVence = vista.getSpinnerFechaVencimiento();

        boolean descontinuado = vista.isDescontinuado();

        int descuento = vista.getSliderDescuentoProducto().getValue();

        String descripcionProd = vista.getTxtAreaDescripcionProducto().getText();

        String lineaProd = vista.getComboLineaProducto()
                .getSelectedItem()
                .toString();
//CREAR EL OBJETO

        Producto prod = new Producto(idProd, nombreProd, precioProd, existenciaProd, fechaVence, descontinuado, descuento, descripcionProd, lineaProd);

        System.out.println("PRODUCTO REGISTRADO");
        System.out.println(prod);

    }// fin del método enviarProducto()

}
